package com.jarvis.ai.data.preferences

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var accentIndex: Int
        get() = prefs.getInt("accent", 0)
        set(v) = prefs.edit().putInt("accent", v).apply()

    var animations: Boolean
        get() = prefs.getBoolean("animations", true)
        set(v) = prefs.edit().putBoolean("animations", v).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_api_key", "") ?: ""
        set(v) = prefs.edit().putString("gemini_api_key", v.trim()).apply()

    var voiceProvider: String
        get() = prefs.getString("voice_provider", "ElevenLabs") ?: "ElevenLabs"
        set(v) = prefs.edit().putString("voice_provider", v).apply()

    var voiceId: String
        get() = prefs.getString("voice_id", "") ?: ""
        set(v) = prefs.edit().putString("voice_id", v.trim()).apply()

    var voiceName: String
        get() = prefs.getString("voice_name", "") ?: ""
        set(v) = prefs.edit().putString("voice_name", v.trim()).apply()

    var voiceApiKey: String
        get() = prefs.getString("voice_api_key", "") ?: ""
        set(v) = prefs.edit().putString("voice_api_key", v.trim()).apply()
}

/** Compose-observable wrapper around [SettingsStore]. */
class AppSettings(private val store: SettingsStore) {
    var accentIndex by mutableIntStateOf(store.accentIndex.coerceIn(0, 3))
        private set
    var animationsEnabled by mutableStateOf(store.animations)
        private set
    var geminiApiKey by mutableStateOf(store.geminiApiKey)
        private set
    var voiceProvider by mutableStateOf(store.voiceProvider)
        private set
    var voiceId by mutableStateOf(store.voiceId)
        private set
    var voiceName by mutableStateOf(store.voiceName)
        private set
    var voiceApiKey by mutableStateOf(store.voiceApiKey)
        private set

    fun updateAccent(index: Int) {
        accentIndex = index
        store.accentIndex = index
    }

    fun updateAnimations(enabled: Boolean) {
        animationsEnabled = enabled
        store.animations = enabled
    }

    fun updateGeminiApiKey(key: String) {
        geminiApiKey = key.trim()
        store.geminiApiKey = key.trim()
    }

    fun updateVoiceSettings(provider: String, id: String, name: String, apiKey: String) {
        voiceProvider = provider
        voiceId = id.trim()
        voiceName = name.trim()
        voiceApiKey = apiKey.trim()
        store.voiceProvider = provider
        store.voiceId = id.trim()
        store.voiceName = name.trim()
        store.voiceApiKey = apiKey.trim()
    }
}
